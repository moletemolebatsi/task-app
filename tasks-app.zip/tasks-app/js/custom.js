// Initialize your app
var myApp = new Framework7({
    modalTitle: 'Tasks'
});

// Export selectors engine
var $$ = Dom7;

// Add views
var mainView = myApp.addView('.view-main', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    dynamicNavbar: true
});

// initialize local storage
var todoData = localStorage.td7Data ? JSON.parse(localStorage.td7Data) : [];

// open popup and set focus
$$('.popup').on('open', function () {
    $$('body').addClass('with-popup');
});

$$('.popup').on('opened', function () {
    $$(this).find('input[name="title"]').focus();
});

// close popup
$$('.popup').on('close', function () {
    $$('body').removeClass('with-popup');
    $$(this).find('input[name="title"]').blur().val('');
});

// Add Task
$$('.popup .add-task').on('click', function () {
    var title = $$('.popup input[name="title"]').val().trim();
    if (title.length === 0) {
        return;
    }
    var color = $$('.popup .color.selected').attr('data-color');
    
    // push to local storage object
    todoData.push({
        title: title,
        color: color,
        checked: '',
        id: (new Date()).getTime()
    });
    
    localStorage.td7Data = JSON.stringify(todoData);
    listHtml();
    myApp.closeModal('.popup');
});

// inject into template engine Template7 template engine
var todoItemTemplateSource = $$('#todo-item-template').html();
var todoItemTemplate = Template7.compile(todoItemTemplateSource);
function listHtml() {
    var renderedList = todoItemTemplate(todoData);
    $$('.todo-items-list').html(renderedList);
}

// Build list html on load
listHtml();